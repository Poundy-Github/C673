The .out executable files will be generated here.
Adding this file, because git does not commit empty folders.