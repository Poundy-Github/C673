/*==========================================================================*/
/*      Copyright (C) 2009-2013 Texas Instruments Incorporated.             */
/*                      All Rights Reserved                                 */
/*==========================================================================*/
#define EVE_MBID   MBOX_ID_0
#define GEM1_MBID  MBOX_ID_1
