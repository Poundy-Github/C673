/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef vh28_evm_hil_cm4__
#define vh28_evm_hil_cm4__



#endif /* vh28_evm_hil_cm4__ */ 
