/*==========================================================================*/
/*      Copyright (C) 2009-2013 Texas Instruments Incorporated.             */
/*                      All Rights Reserved                                 */
/*==========================================================================*/


/**
 *  @file       eve_edma_functions.c
 *
 *  @brief      This header defines functions to use EDMA
 */

/*-----------------------------------------------------------------------*/
/*  Standard header includes for c environment.                          */
/*-----------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*/
/*  These are the include files that are needed for edma/qdma.           */
/*-----------------------------------------------------------------------*/
#include "dma_funcs.h"
#include "edmacc_config.h"

#define CSL_QUE_PRI0     0x00000000U
#define CSL_QUE_PRI3     0x00000003U

/* ==================================================
 *  @func     DMA_funcs_hardwareRegSetup
 *
 *  @desc   This function updates the actual hardware register based on
 *          DMA_resourceStruct. For QDMA we will be setting up QCHMAP,
 *          QDMAQNUM, QEESR. Similarly for EDMA we will be setting
 *          up, DCHMAP, DMAQNUM. Independent of QDMA and EDMA we configure
 *          QUEWTHRA, QUEPRI and QUETCMAP registers.
 *          In current implementation there is a one to one mapping
 *          between transfer controllers and hardware queues. TC0 is
 *          mapped to Q0 and TC1 is mapped to Q1, this means Q0 submits
 *          on TC0 and Q1 submits on TC1.
 *          More over Q0 is given a higher priority compare to Q1.
 *          Currently Trigger word for QDMA channel is set to 7.
 *
 *
 *  @modif    This function modifies edmaCc
 *
 *  @inputs   This function takes following Inputs
 *                  edmaCc :
 *                      Pointer to the address space of EDMA module
 *                  edmaResources :
 *                      Pointer to the resource Structure as defined in dma_resource.h
 *
 *  @outputs NONE
 *
 *   @return    0 : Success
 *             -1 : Failure
 *
 *  =======================================================
 */
int32_t DMA_funcs_hardwareRegSetup(CSL_EdmaccRegsOvly edmaCc,
                                const DMA_resourceStruct * edmaResources)
{
    uint32_t            evtNo;
    uint32_t            queNo;
    uint32_t            trigWord;
    uint32_t            queRem;
    uint32_t            queShift;
    uint32_t            prmNo;
    uint32_t            dmaAttr;
    int32_t             channelCnt;
    uint32_t             queRegNo;
    volatile uint32_t   *baseParam;
    int32_t             status = 0;

    if ( edmaResources == NULL )
    {
        status = -1;
    }

    if ( status == 0 )
    {
        /*-------------------------------------------------------------------*/
        /*  First setup the quee to TC mapping, we setup 1 to 1 mapping and  */
        /*  this needs to be verified based on FIFO properties. For now Q0   */
        /*  submits on TC0, and similarly Q1 submits on TC1.                 */
        /*-------------------------------------------------------------------*/

        /* The uint8_t casts below are to satisfy MISRA-C rule 10.5 ... however,
        if the underlying shift values change this cast needs to change to be able
        to contain the larger register size */
        edmaCc->QUETCMAP = (uint8_t)(CSL_EDMACC_CCCFG_NUM_TC_1 <<
                                CSL_EDMACC_QUETCMAP_TCNUMQ0_SHIFT) |
                                (uint8_t)(CSL_EDMACC_CCCFG_NUM_TC_2 <<
                                CSL_EDMACC_QUETCMAP_TCNUMQ1_SHIFT);

        /*-------------------------------------------------------------------*/
        /*  We need to verify priority values, but for now, DDR traffic is   */
        /*  given higher priority, and co-processor commands are given le    */
        /*  sser priority. We program these without accepting user inputs    */
        /*  as this could impact performance, so we calibrate this on QT     */
        /*  and set it here.                                                 */
        /*-------------------------------------------------------------------*/

        edmaCc->QUEPRI =
            ((uint32_t)CSL_QUE_PRI3 << CSL_EDMACC_QUEPRI_PRIQ0_SHIFT) |
                    ((uint32_t)CSL_QUE_PRI0 << CSL_EDMACC_QUEPRI_PRIQ1_SHIFT);

        /*-------------------------------------------------------------------*/
        /* Also set up the threshold register though this is strictly not    */
        /* needed.                                                           */
        /*-------------------------------------------------------------------*/

        edmaCc->QWMTHRA = CSL_EDMACC_QWMTHRA_RESETVAL & 0xFFFFU;

        /*-------------------------------------------------------------------*/
        /*  Now iterate for each of the channels and setup the other regs.   */
        /*  based on channel attribute.                                      */
        /*-------------------------------------------------------------------*/
        for (channelCnt = 0 ; channelCnt < edmaResources->numChannels ; channelCnt++)
        {
            /*---------------------------------------------------------------*/
            /*  Read specific event num, tcc, region, trigger param, base    */
            /*  param, number of paramns, trfPend locn, dma attrib, of      */
            /*  channel, queNo for request.                                 */
            /*---------------------------------------------------------------*/


            evtNo = edmaResources->logicalChannelNo[channelCnt];
            queNo = (uint32_t)edmaResources->queNo[channelCnt] & 0x01U;
            baseParam = edmaResources->baseParam[channelCnt];
            dmaAttr = edmaResources->dmaAttr[channelCnt];

            if ( dmaAttr == DMA_CHAN_ATTR_EDMA )
            {

                /*---------------------------------------------------------------*/
                /*  If it is EDMA channel, we setup DCHMAP, DMAQNUM, DRAE. This  */
                /*  will tie down specific PARAM to event, queue for event, and  */
                /*  region where completion interrupt must go.                   */
                /*---------------------------------------------------------------*/

                prmNo = ((uint32_t) baseParam - (uint32_t)edmaCc->PARAMENTRY)
                            >> CSL_EDMACC_DCHMAP_PAENTRY_SHIFT;

#ifdef DMA_ASSERT
                    assert (evtNo >= 0U);
                    assert (evtNo <= NUM_EDMA_CHANNELS);
                    assert (queNo >= 0U);
                    assert (queNo <= 1U);
                    assert (prmNo >= 0U);
                    assert (prmNo <= EDMA_NUM_PARAMS);
                    assert (edmaResources->numChannels <= NUM_MAX_CHANNELS);
#endif

                    /*-----------------------------------------------------------*/
                    /*  Write the corresponding param for evt no evtNo, each    */
                    /*  of the 64 events has an associated register. This is     */
                    /*  the difference between the current param address and     */
                    /*  base PARAM address. This gives offset in bytes, 32       */
                    /*  bytes makes a PARAM, so to get PARAM no, we divide       */
                    /*  by 32, note DCHMAP finally ends up taking this offset    */
                    /*  so we can avoid right shifting and left shifting by 5    */
                    /*  as we optimize cycles.                                   */
                    /*-----------------------------------------------------------*/
                    edmaCc->DCHMAP[evtNo] = (uint32_t) prmNo << CSL_EDMACC_DCHMAP_PAENTRY_SHIFT;

                    /*-----------------------------------------------------------*/
                    /*  Queue to use for the 64 event is present in 8 regs. So   */
                    /*  we determine regNo, and offset within that register.    */
                    /*  Offset within reg, is used to decide shift.              */
                    /*-----------------------------------------------------------*/

                    queRegNo = evtNo >> 3U;
                    queRem = evtNo - (8U * queRegNo);

#ifdef DMA_ASSERT
                    assert (queRem >= 0U);
                    assert (queRem <= 7U);
#endif

                    if (queRem == 0U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E0_SHIFT;
                    }
                    if (queRem == 1U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E1_SHIFT;
                    }
                    if (queRem == 2U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E2_SHIFT;
                    }
                    if (queRem == 3U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E3_SHIFT;
                    }
                    if (queRem == 4U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E4_SHIFT;
                    }
                    if (queRem == 5U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E5_SHIFT;
                    }
                    if (queRem == 6U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E6_SHIFT;
                    }
                    if (queRem == 7U)
                    {
                        queShift = CSL_EDMACC_DMAQNUM_E7_SHIFT;
                    }

                    /*-----------------------------------------------------------*/
                    /*  Now we can write in DMAQNUM, the queue number, at the    */
                    /*  correct location.                                        */
                    /*-----------------------------------------------------------*/

                     edmaCc->DMAQNUM[queRegNo] = (edmaCc->DMAQNUM[queRegNo]  & ~(1<<queShift) ) |
                                              (queNo << queShift);
            }
            else
            {
#ifdef DMA_ASSERT
                assert (evtNo >= 0U);
                assert (evtNo <= NUM_QDMA_CHANNELS);
                assert (queNo >= 0U);
                assert (queNo <= 1U);
                assert (edmaResources->numChannels <= NUM_QDMA_CHANNELS);
#endif

                /*-----------------------------------------------------------*/
                /* For QDMA we have an associated QDMA enable register.      */
                /*-----------------------------------------------------------*/

                if (evtNo == 0U)
                {
                    queShift = CSL_EDMACC_QEESR_E0_SHIFT;
                }
                if (evtNo == 1U)
                {
                    queShift = CSL_EDMACC_QEESR_E1_SHIFT;
                }
                if (evtNo == 2U)
                {
                    queShift = CSL_EDMACC_QEESR_E2_SHIFT;
                }
                if (evtNo == 3U)
                {
                    queShift = CSL_EDMACC_QEESR_E3_SHIFT;
                }
                if (evtNo == 4U)
                {
                    queShift = CSL_EDMACC_QEESR_E4_SHIFT;
                }
                if (evtNo == 5U)
                {
                    queShift = CSL_EDMACC_QEESR_E5_SHIFT;
                }
                if (evtNo == 6U)
                {
                    queShift = CSL_EDMACC_QEESR_E6_SHIFT;
                }
                if (evtNo == 7U)
                {
                    queShift = CSL_EDMACC_QEESR_E7_SHIFT;
                }

                edmaCc->QEESR = 0x1U << queShift;

                /*-----------------------------------------------------------*/
                /*  For QDMA channel we write both param amd trigger word.   */
                /*-----------------------------------------------------------*/
                trigWord = edmaResources->trigWordIndex[channelCnt];

                prmNo = ((uint32_t) baseParam - (uint32_t) &edmaCc->PARAMENTRY[0])
                        >> CSL_EDMACC_QCHMAP_PAENTRY_SHIFT;

                edmaCc->QCHMAP[evtNo] = ((uint32_t) prmNo << CSL_EDMACC_QCHMAP_PAENTRY_SHIFT )
                                         | (trigWord << CSL_EDMACC_QCHMAP_TRWORD_SHIFT);

                /*-----------------------------------------------------------*/
                /*  In QDMAQNUM, we write the queue number specified by the  */
                /*  user, as evtNo has to be one of 8 QDMA channels. We     */
                /*  also write a 1, into the region requested by user.       */
                /*-----------------------------------------------------------*/

                queRem = evtNo;
                if (queRem == 0U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E0_SHIFT;
                }
                if (queRem == 1U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E1_SHIFT;
                }
                if (queRem == 2U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E2_SHIFT;
                }
                if (queRem == 3U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E3_SHIFT;
                }
                if (queRem == 4U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E4_SHIFT;
                }
                if (queRem == 5U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E5_SHIFT;
                }
                if (queRem == 6U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E6_SHIFT;
                }
                if (queRem == 7U)
                {
                    queShift = CSL_EDMACC_QDMAQNUM_E7_SHIFT;
                }

                edmaCc->QDMAQNUM =  (edmaCc->QDMAQNUM & ~(1<<queShift) ) |
                                              (queNo << queShift) ;
            }
        }
    }
    return status;
}

/* ==================================================
 *  @func     DMA_funcs_writeTransferParams
 *
 *  @desc     This function populates the param set based on the inputs.
 *            It is to be noted that this API will automatically trigger
 *            QDMA channel transfer because it writes to all the param
 *            set entries
 *
 *  @modif    This function modifies param set
 *
 *  @inputs   This function takes following Inputs
 *                  tparam :
 *                      Trigger param where you want to write
 *                  optWord :
 *                      Opt word for the param set corresponding to the
 *                      channel number given
 *                  srcPtr :
 *                      Pointer to the source
 *                  dstPtr :
 *                      Pointer to the destination
 *                  noBytes :
 *                      Number of bytes to be transfered (Acnt)
 *                  noLines :
 *                      Number of lines of noBytes (Bcnt)
 *                  srcLinePitch :
 *                      Pitch for the source pointer
 *                  dstLinePitch :
 *                      Pitch for the destination pointer
 *                  srcNextBlkOffset :
 *                      Offset for the next block in for source
 *                  dstNextBlkOffset :
 *                      Offset for the next block for destination
 *                  numAutoIncr :
 *                      Number of times autoincrement to be executed (Ccnt)
 *                  linkAddr :
 *                      Link address for the cases when you want to link
 *                      one param set to another
 *                      Default value = 0, in this case it will write 0xFFFF
 *
 *  @outputs NONE
 *
 *
 *  =======================================================
 */
  /* This decleration violates MISRA-C Rule 16.7 : MISRA.PPARAM.NEEDS.CONST.
 This cannot be avoided because dstPtr is actually modified by the EDMA hardware
 but from the code compiler cannot detect this and hence returns a warning */
void DMA_funcs_writeTransferParams(volatile uint32_t * tparam, uint32_t optWord,
                    const uint8_t *srcPtr, uint8_t *dstPtr, uint16_t noBytes, uint16_t noLines,
                    int16_t srcLinePitch, int16_t dstLinePitch, int16_t srcNextBlkOffset,
                    int16_t dstNextBlkOffset, uint16_t numAutoIncr, uint16_t linkAddr)
{
    tparam[0] = (uint32_t) optWord;
    tparam[1] = (uint32_t) srcPtr;
    tparam[2] = pack2(noLines, noBytes);
    tparam[3] = (uint32_t) dstPtr;
    tparam[4] = (uint32_t)pack2((uint16_t)dstLinePitch, (uint16_t)srcLinePitch);
    if ( linkAddr == 0)
    {
        tparam[5] = pack2(noLines, 0xFFFFU);
    }
    else
    {
        tparam[5] = pack2(noLines, linkAddr);
    }
    tparam[6] = (uint32_t)pack2((uint16_t)dstNextBlkOffset, (uint16_t)srcNextBlkOffset);
    tparam[7] = numAutoIncr;
}

