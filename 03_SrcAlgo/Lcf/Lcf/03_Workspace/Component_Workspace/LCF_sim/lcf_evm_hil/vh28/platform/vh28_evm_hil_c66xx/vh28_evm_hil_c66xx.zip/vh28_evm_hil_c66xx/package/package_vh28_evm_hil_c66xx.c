/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#include <xdc/std.h>

__FAR__ char vh28_evm_hil_c66xx__dummy__;

#define __xdc_PKGVERS null
#define __xdc_PKGNAME vh28_evm_hil_c66xx
#define __xdc_PKGPREFIX vh28_evm_hil_c66xx_

#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

