/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef Vayu_DSP1__
#define Vayu_DSP1__



#endif /* Vayu_DSP1__ */ 
