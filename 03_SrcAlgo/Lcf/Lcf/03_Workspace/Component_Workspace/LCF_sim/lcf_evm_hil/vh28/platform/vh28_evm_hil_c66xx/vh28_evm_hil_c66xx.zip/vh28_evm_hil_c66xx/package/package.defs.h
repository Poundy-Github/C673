/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef vh28_evm_hil_c66xx__
#define vh28_evm_hil_c66xx__



#endif /* vh28_evm_hil_c66xx__ */ 
